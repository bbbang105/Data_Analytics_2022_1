##########################################
# 과목명 : 데이터 애널리틱스
# 과제명 : 3 – 계층적군집분석
# 이름 : 한상호
# 학번 : 2018111366
# 학과 : 경영정보
##########################################

## 1. crabs의 FL, RW, CL, CW, BD 데이터로 
## 구성된 데이터프레임 crabs.df 생성
library(MASS)
crabs
crabs.df <- data.frame(scale(crabs[4:8]))

## 2. crabs.df의 유클리디안 거리행렬 crabs.dist 산정
crabs.dist <- dist(crabs.df, method = "euclidean")

## 3. crabs.dist에 대한 덴드로그램 작성 후 k=4가 되도록 절단,
## k=4일 경우 군집이 어떻게 나누어지는지 덴드로그램에 시각화
hc1 <- hclust(crabs.dist, method = "complete")
plot(hc1, hang = -1, ann = FALSE)

memb <- cutree(hc1, k = 4)

rect.hclust(hc1, k = 4)

## 4. crabs.df에 k=4인 hclust 결과를 cbind하여 crabs.df 업데이트
row.names(crabs.df) <- paste(memb, ": ", 
                             row.names(crabs), 
                              sep = "")

## 5. 수정된 crabs.df의 heatmap 작성
heatmap(as.matrix(crabs.df), Colv = NA, hclustfun=hclust, 
        col=rev(paste("gray",1:99,sep="")))

## 6. k=4가 적절한지 서술해보기

# k=4일때 히트맵을 보면, 
# (1) FL은 2,3 군집에서 약간은 강세지만 전반적으로 약세를 보인다.
# (2) RW는 변수들 중 유일하게 모든 군집에서 높은 수치를 보이고 있다.
# (3) CL은 RW가 약세인 부분에서 강세를 보여준다.
# (4) CW는 전반적으로 약하지만, CL과 비슷한 부분에서 강세를 보이고 있다.
# (5) BD는 2,4 군집에서 강세를 보인다.

## 총평: 구분이 완전히 되는 것 같지는 않아 아쉬운 부분도 있지만,
# RW의 명확성과, RW와 CL,CW 간의 차이는 뚜렷히 보여 긍정적인 면도
# 존재하는 것 같다. 덧붙여 k의 수치를 높여 진행했을 때도 비슷한
# 양상을 보이므로, 현재의 k=4라는 수치는 적절하다고 생각한다.
