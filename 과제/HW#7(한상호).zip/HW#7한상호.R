##########################################
# 과목명 : 데이터 애널리틱스
# 과제명 : 7 - 토픽모델링
# 이름 : 한상호
# 학번 : 2018111366
# 학과 : 경영정보
##########################################


## 0. library 로딩
library(topicmodels)
library(tidytext)
library(tidyr) 
library(ggplot2)
library(dplyr)

## 1. DTM이 내장된 amazonDTM.Rdata 불러오기
setwd('c:/ba')
load(file="c:/ba/amazonDTM.Rdata")


## 2. amazonDTM를 이용하여 LDA 만들기

# K=3 , 샘플링 방식은 Gibbs
# seed는 자유롭게 설정
ama_lda <- LDA(amazonDTM,
               k = 3,
               method = "Gibbs",
               control = list(seed = 1357))


## 3. 토픽 별 그래프 제출
ama_topics <- tidy(ama_lda, matrix = "beta")
ama_topics

ama_top_terms <- ama_topics %>%
  group_by(topic) %>%
  top_n(10, beta) %>%
  ungroup() %>%
  arrange(topic, -beta)

ama_top_terms

ama_top_terms %>%
  mutate(term = reorder_within(term, beta, topic)) %>%
  ggplot(aes(term, beta, fill = factor(topic))) +
  geom_col(show.legend = TRUE) +
  facet_wrap(~ topic, scales = "free") +
  coord_flip() +
  scale_x_reordered()

## 4. 토픽 별 쌍대 비교
# beta_spread1 : topic 1과 topic2 비교
beta_spread1 <- ama_topics %>%
  mutate(topic = paste0("topic", topic)) %>%
  spread(topic, beta) %>%
  filter(topic1 > .001 | topic2 > .001) %>%
  mutate(log_ratio = log2(topic2 / topic1))

beta_spread1

# ggplot을 이용하여 beta_spread1의 그래프 생성
beta_spread1 %>%
  group_by(direction = log_ratio > 0) %>%
  top_n(10, abs(log_ratio)) %>%
  ungroup() %>%
  mutate(term = reorder(term, log_ratio)) %>%
  ggplot(aes(term, log_ratio)) +
  geom_col() +
  labs(y = "Log2 ratio of beta in topic 2 / topic 1") +
  coord_flip()

# beta_spread2 : topic 1과 topic3 비교
beta_spread2 <- ama_topics %>%
  mutate(topic = paste0("topic", topic)) %>%
  spread(topic, beta) %>%
  filter(topic1 > .001 | topic3 > .001) %>%
  mutate(log_ratio = log2(topic3 / topic1))

beta_spread2

# ggplot을 이용하여 beta_spread2의 그래프 생성
beta_spread2 %>%
  group_by(direction = log_ratio > 0) %>%
  top_n(10, abs(log_ratio)) %>%
  ungroup() %>%
  mutate(term = reorder(term, log_ratio)) %>%
  ggplot(aes(term, log_ratio)) +
  geom_col() +
  labs(y = "Log2 ratio of beta in topic 3 / topic 1") +
  coord_flip()

# beta_spread3 : topic 2와 topic3 비교
beta_spread3 <- ama_topics %>%
  mutate(topic = paste0("topic", topic)) %>%
  spread(topic, beta) %>%
  filter(topic2 > .001 | topic3 > .001) %>%
  mutate(log_ratio = log2(topic3 / topic2))

beta_spread3

# ggplot을 이용하여 beta_spread3의 그래프 생성
beta_spread3 %>%
  group_by(direction = log_ratio > 0) %>%
  top_n(10, abs(log_ratio)) %>%
  ungroup() %>%
  mutate(term = reorder(term, log_ratio)) %>%
  ggplot(aes(term, log_ratio)) +
  geom_col() +
  labs(y = "Log2 ratio of beta in topic 3 / topic 2") +
  coord_flip()

## 5. 구축된 모형으로부터 gamma(문서 별 토픽 확률분포) 도출
ama_documents <- tidy(ama_lda, matrix = "gamma")

ama_documents

ama_top_documents <- ama_documents %>%
  group_by(document) %>%
  top_n(3, gamma) %>%
  ungroup() %>%
  arrange(document, -gamma)

ama_top_documents
