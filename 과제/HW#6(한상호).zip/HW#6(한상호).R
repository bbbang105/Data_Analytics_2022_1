##########################################
# 과목명 : 데이터 애널리틱스
# 과제명 : 6 – 텍스트마이닝
# 이름 : 한상호
# 학번 : 2018111366
# 학과 : 경영정보
##########################################

library(tm)

library(topicmodels)

setwd("C:/ba")

amazon <- read.csv('Oculus-Quest-Advanced-All-One-Virtual.csv', stringsAsFactors = FALSE)

amazon$Title[1:3]

Oculus <- iconv(enc2utf8(amazon$Review), sub='bytes')

Oculus <- gsub("[\U4E00-\U9FFF\U3000-\U303F]","",Oculus)

Oculus <- iconv(Oculus, from="latin1", to="ASCII", sub="")

Oculus[32] 

corpus <- VCorpus(VectorSource(Oculus))

inspect(corpus[32])

Sys.setlocale()

Sys.setlocale(category = "LC_ALL", locale = "us")

tdm <- TermDocumentMatrix(corpus, control=list( removePunctuation=T,
                                                stopwords= 'SMART',
                                                tolower = T,
                                                removeNumbers = T,
                                                wordLength = c(3,7),
                                                stemming = F,
                                                stripWhitespace = T,
                                                weighting = weightTfIdf
))


dim(tdm)

library(lsa)

amazon_TM <- as.textmatrix(as.matrix(tdm))

amazon_lsa <- lsa(amazon_TM, dim=7)

dim(amazon_lsa$tk)

dim(amazon_lsa$dk)

length(amazon_lsa$sk)

