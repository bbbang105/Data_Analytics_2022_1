##########################################
# 과목명 : 데이터 애널리틱스
# 과제명 : 2 – K군집분석
# 이름 : 한상호
# 학번 : 2018111366
# 학과 : 경영정보
##########################################

# 1. “snsdata.csv” 데이터로 teens 데이터프레임 생성
teens <- read.csv("snsdata.csv")


# 2. Teens의 age에 대하여 결측인 행 제거
summary(teens$age)

teens$age <- ifelse(teens$age >= 13 & teens$age < 20,
                    teens$age, NA)

summary(teens$age)

ave_age <- ave(teens$age, teens$gradyear,
               FUN = function(x) mean(x, na.rm = TRUE))

teens$age <- ifelse(is.na(teens$age), ave_age, teens$age)

summary(teens$age)


# 3. Teens의 13 ~ 37열의 자료를 이용하여 interests 데이터프레임 생성
interests <- teens[13:37]

interests_z <- as.data.frame(lapply(interests, scale))


# 4. kmeans를 이용하여, teen_clusters 생성
set.seed(2022)

teen_clusters <- kmeans(interests_z, 5)


# 5. interests_z 에 군집 번호를 cbind 하여 
# 군집 번호가 포함된 데이터 프레임 생성
interests_z$cluster <- teen_clusters$cluster

colnames(interests_z)


## 6. 각 군집별 해석
teen_clusters$size
teen_clusters$centers

# 1번 군집 학생(N=810)들은 band, marching, music, rock이
# 높은 것을 보아 음악과 노는 것을 즐기며 상당히 활발한 
# 성격의 학생들로 파악됨.

# 2번 군집 학생(N=5583)들은 cute, sexy, hot, dance, dress,
# mall, shopping이 높은 것을 보아 본인을 꾸미고 과시하는
# 것에 대한 욕구가 높다고 판단됨. 반면, god, church의 수치도
# 높아 약간은 모순적(?)인 느낌이 듦.

# 3번 군집 학생(N=874)들은 hair, mall, shopping, clothes가
# 높은 것을 보아 패션에 상당한 관심이 있고, 특히 hollister,
# abercrombie가 굉장히 높은 것을 보면 이 두 브랜드에 대한
# 관심이 높다고 여겨짐.

# 4번 군집 학생(N=21963)들은 모든 항목이 마이너스인 것을
# 보아 모든 것에 관심이 없다고 여겨짐. 다만, 학생의 수가
# 너무 커 정확한 판단을 내리기엔 무리가 있음.

# 5번 군집 학생(N=770)들은 sports, sex, kissed가 굉장히
# 높은 것을 보아, 운동부에 속해 있거나 성욕이 높은 
# 혈기왕성한 학생들이라고 판단됨.

