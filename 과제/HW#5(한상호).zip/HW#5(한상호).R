##########################################
# 과목명 : 데이터 애널리틱스
# 과제명 : 5 – 크롤링
# 이름 : 한상호
# 학번 : 2018111366
# 학과 : 경영정보
##########################################

setwd('C:/ba')

library(tidyverse)
library(rvest)

####### 크롤링할 HTML 코드 #######

scrap_amazon <- function(ASIN, page_num){
  
  url_reviews <- paste0("https://www.amazon.com/Oculus-Quest-Advanced-All-One-Virtual/product-reviews/",ASIN,"/?pageNumber=",page_num)
  doc <- read_html(url_reviews)
  
  ## data-hook 또는 class로 불러오기
  
  # Review Date
  doc %>%
    html_nodes("[class = 'a-size-base a-color-secondary review-date']")%>%
    html_text() -> Data
  
  # Review Title
  doc %>%
    html_nodes("[class='a-size-base a-link-normal review-title a-color-base review-title-content a-text-bold']")%>%
    html_text() -> Title
  
  # Review Text
  doc %>%
    html_nodes("[class='a-row a-spacing-small review-data']")%>%
    html_text() -> Review
  
  # Number of Stars in Review
  doc %>%
    html_nodes("[title='1.0 out of 5 stars']")%>%
    html_text() -> Rating
  
  # Number of people found this helpful
  doc %>%
    html_nodes("[class='a-size-base a-color-tertiary cr-vote-text']")%>%
    html_text() -> Nhelp
  
  # Return a tibble
  tibble(Data,
         Title, 
         Review, 
         Rating, 
         Page = page_num, 
         Nhelp)%>%
    return()
}

######## Page별 크롤링 시작 #########

# Product name = Oculus-Quest-Advanced-All-One-Virtual
# ASIN = B099VMT8VZ
review_all <- vector( "list", length = 5)

# 스크랩 시작
for (i in 1:5){
  review_all[[i]] <- scrap_amazon(ASIN = "B099VMT8VZ", page_num = i)
}

# review_all 내용을 rbind를 이용하여 한줄씩 리뷰를 저장
amazon <- do.call(rbind, review_all)

######## 텍스트 전처리 #########

# Rating에서 ".0 out of 5 stars" 지우기
# 뒤에 부분을 제거하여 점수만 확인
amazon$Rating <- gsub(".0 out of 5 stars", "", amazon$Rating )

# Data에서 국가와 날짜 분리하기
# “ on”과 “on ”을 기준으로 문장을 나눔
# Country와 Date 생성
amazon$Country <- strsplit(amazon$Data, " on")[[1]][1]
amazon$Country <- gsub("Reviewed in ", "", amazon$Country)
amazon$Date <- strsplit(amazon$Data, "on ")[[1]][2]

# 필요없어진 Data 속성 제거
amazon <- amazon[,-1]

# Pattern을 이용하여 newline을 의미하는 “\n” 지우고,
# 두 칸 white space 없애기
amazon$Title <- gsub(pattern="\\n", "", amazon$Title)
amazon$Review <- gsub(pattern="\\n", "", amazon$Review)
amazon$Title <- gsub(" ", "", amazon$Title)
amazon$Review <- gsub(" ", "", amazon$Review)

# 속성 중요도에 따라 reorder
amazon <- amazon[ , c(6,5,3,1,7,2,4)]

# CSV 저장하기
write.csv(amazon, file= "Oculus-Quest-Advanced-All-One-Virtual.csv", row.names = FALSE)