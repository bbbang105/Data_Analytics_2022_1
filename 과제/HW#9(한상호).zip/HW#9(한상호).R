##########################################
# 과목명 : 데이터 애널리틱스
# 과제명 : 9 - 감성분석
# 이름 : 한상호
# 학번 : 2018111366
# 학과 : 경영정보
#########################################

setwd("C:/ba")

library(readr)
library(SentimentAnalysis)
library(stringr)
library(tm)

### 1. 분석 실행
rev <- read_delim("review_dict.txt", delim="\t", col_names=c("word", "score"))

head(rev, 10)

sentdic <- SentimentDictionaryWeighted(words = rev$word, scores = rev$score)

sentdic <- SentimentDictionary(rev$word[rev$score>0], rev$word[rev$score<0])

summary(sentdic)

txt <- readLines("review_example.txt", encoding = "UTF-8")
head(txt)

txt_2 <- str_replace_all(txt, "([.,!?])","")
head(txt_2)
txt_2

class(txt_2)

co_txt <- Corpus(VectorSource(txt_2))
class(co_txt) 
inspect(co_txt)

dtm_txt <- DocumentTermMatrix(co_txt)

inspect(dtm_txt)

res <- analyzeSentiment(dtm_txt, language="korean", 
                        rules=list("sentiment"=list(ruleSentiment, sentdic)))

head(res)

res$pn <- ifelse(res$sentiment>0,"Positive",
                 ifelse(res$sentiment==0,"Neutral","Negative"))
head(res)

table(res$pn)

df_res <- as.data.frame(table(res$pn))

df_res <- rbind(df_res,data.frame(Var1 = "Negative",Freq = 0))

names(df_res) <- c("res","freq")



### 2. 막대 그래프로 결과 시각화
barplot(df_res$freq, names = c("Neutral","Positive","Negative"), 
        main = "리뷰 감성분석 막대 그래프", xlab = "Positive/Neutral/Negative",
        ylab = "Number", col = rainbow(2))

### 3. Positive로 분석된 리뷰 텍스트 확인
txt_positive <- subset(txt, res$pn == "Positive")
txt_positive

# 분석 설명: txt_positive를 보면, 긍정적인 리뷰들만 존재하므로
# Positive항목은 분석이 잘 되었다.

### 4. Neutral로 분석된 리뷰 텍스트 확인
txt_neutral <- subset(txt, res$pn == "Neutral")
txt_neutral

# 분석 설명: txt_neutral를 보면, 칭찬과 비판이 함께 있는 중립적인 의견이 
# 주로 있어야하는데, 긍정적인 의견과 부정적인 의견들도 많이 보이고 있으므로
# 분석이 잘 되지 않았다.

### 5. Negative로 분석된 리뷰 텍스트 확인
txt_negative <- subset(txt, res$pn == "Negative")
txt_negative

# Negative항목은 한 개도 나오지 않아 분석이 불가능하다.

### 6. 총평
# 리뷰 데이터를 살펴보면, 분명히 부정적인 의견들도 많이 보이는데 분석 결과
# 상으로는 Negative가 존재하지 않았다. 이는 review_dict에 항목을 추가함으로써
# 해결할 수 있을 것으로 생각된다. 예를 들어 리뷰에는 'ㅜㅜ'가 부정적인 의견에
# 많이 사용되었는데, review_dict에는 'ㅠㅠ'항목만이 존재해 제대로 분석이 되지
# 않았다. 또한 '퍽퍽해요'항목은 있지만 리뷰에서는 '뻑뻑'을 사용해 정확한 점수
# 측정이 불가했다. 그러므로 review_dict에 'ㅜ', 'ㅜㅜ', '뻑뻑', '별로', '버렸', '맛없'을
# Negative 요소로, '좋아', '맛있', '베스트', '훌륭', '꼼꼼', '최고', '대박'을
# Positive 요소로 추가한다면 더욱 정확한 분석이 가능할 것으로 보인다.
