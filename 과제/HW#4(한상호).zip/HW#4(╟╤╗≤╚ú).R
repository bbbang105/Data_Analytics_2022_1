##########################################
# 과목명 : 데이터 애널리틱스
# 과제명 : 4 – 자기조직화
# 이름 : 한상호
# 학번 : 2018111366
# 학과 : 경영정보
##########################################

setwd('C:/ba')

## 1. kohonen 패키지에 내장된 wines 데이터를 불러와서 다음 조건으로 데이터 생성
library(kohonen)
library(dummies)
data("wines")
data_train <- wines[, c(1,3,5,7,11)]
data_train_matrix <- as.matrix(scale(data_train))

## 2. somgrid를 다음 조건으로 생성
som_grid <- somgrid(xdim = 12, ydim=12, topo="hexagonal")

## 3. 2.를 이용하여 som 생성
set.seed(2022)
som_model <- som(data_train_matrix, 
                 grid=som_grid, 
                 rlen=100, 
                 alpha=c(0.3,0.01), 
                 keep.data = TRUE )

## 4. hclust와 cutree 함수를 이용하여 cluster 생성
som_cluster <- cutree(hclust(dist(getCodes(som_model))), 5)

## 5. plot 생성
source('coolBlueHotRed.R')

plot(som_model, type = "codes", main="2018111366_한상호", 
     palette.name=coolBlueHotRed)

pretty_palette <- c('#F26041', '#F0B61F', '#9FF215', 
                    '#0FE786', '#288BF0')

plot(som_model, type="codes", bgcol = pretty_palette[som_cluster], 
     main = "2018111366_한상호")

## 6. add.cluster.boundaries 함수를 통해 plot에 경계 구분 선 추가
add.cluster.boundaries(som_model, som_cluster)
