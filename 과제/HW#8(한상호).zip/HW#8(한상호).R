##########################################
# 과목명 : 데이터 애널리틱스
# 과제명 : 8 - 사회연결망분석
# 이름 : 한상호
# 학번 : 2018111366
# 학과 : 경영정보
##########################################

setwd("C:/ba")

# 라이브러리 로딩
library(igraph)

## 1.
# 아마존 데이터 세트 읽기
amazonnet <- read.table("Amazon_product_co-purchasing network.txt", header=F)
head(amazonnet)
tail(amazonnet)

# amazonnet 데이터를 그래프 형식의 데이터 프레임으로 변환
amazonnet.df <- graph.data.frame(amazonnet, directed=FALSE)
plot(amazonnet.df)

## 2.
# 아마존 ID 202번에 대한 데이터셋 연결
am202 <- subset(amazonnet, amazonnet$V1==202)

# am202.df 데이터를 그래프 형식의 데이터 프레임으로 변환
am202.df <- graph.data.frame(am202, directed=FALSE)

## 3. 시각화 출력
# ID 202 만의 아이템 연결망 출력
plot(am202.df)

# amazonnet.df에 대한 분포 시각화 출력
plot(degree(amazonnet.df), xlab="사용자 번호", ylab="연결 정도", 
     type='h')

## 4.Degree, closeness, betweenness centrality 값 출력

# Degree
degree(amazonnet.df, normalized=TRUE)
tmax <- centralization.degree.tmax(amazonnet.df)
centralization.degree(amazonnet.df, 
                         normalized=FALSE)$centralization / tmax
# closeness
closeness(amazonnet.df, normalized=TRUE)
tmax <- centralization.closeness.tmax(amazonnet.df)
centralization.closeness(amazonnet.df, 
                      normalized=FALSE)$centralization / tmax
# betweenness
betweenness(amazonnet.df, normalized=TRUE)
tmax <- centralization.betweenness.tmax(amazonnet.df)
centralization.betweenness(amazonnet.df, 
                      normalized=FALSE)$centralization / tmax
